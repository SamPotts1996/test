﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace RelayControl.Views.CustomControls
{
    /// <summary>
    /// Interaction logic for RelaySwitchPanel.xaml
    /// </summary>
    public partial class RelaySwitchPanel : UserControl
    {
        private DispatcherTimer _timer;
        private int _duration;
        private bool _repeat;

       
        private DateTime _startTime;
      

        public RelaySwitchPanel()
        {
            InitializeComponent();

            _timer = new DispatcherTimer();
            _timer.Tick += Timer_Tick;
            _duration = 0;
            _startTime = DateTime.Now;
            SchedulePanel.Visibility = Visibility.Collapsed;
        }

        public static readonly DependencyProperty IsOnProperty =
               DependencyProperty.Register("IsOn", typeof(bool), typeof(RelaySwitchPanel),
                   new FrameworkPropertyMetadata(false, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault, new PropertyChangedCallback(IsOnChanged)));

        public bool IsOn
        {
            get => (bool)GetValue(IsOnProperty);
            set => SetValue(IsOnProperty, value);
        }

        private static void IsOnChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var control = d as RelaySwitchPanel;
            bool isOn = (bool)e.NewValue;
            if (isOn)
            {
                VisualStateManager.GoToState(control, "On", true);
            }
            else
            {
                VisualStateManager.GoToState(control, "Off", true);
            }
        }

        private void SwitchBorder_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (ScheduleCheckBox.IsChecked == true)
            {
                if (IsValidStartTime() && IsValidDuration())
                {
                    VisualStateManager.GoToState(this, "Set", true);
                    TimeSpan timeUntilStart = _startTime - DateTime.Now;
                    if (timeUntilStart > TimeSpan.Zero)
                    {
                        DispatcherTimer delayTimer = new DispatcherTimer();
                        delayTimer.Interval = timeUntilStart;
                        delayTimer.Tick += (s, args) =>
                        {
                            delayTimer.Stop();
                            StartTimer();
                        };
                        delayTimer.Start();
                    }
                    else
                    {
                        StartTimer();
                    }
                }
            }
            else
            {
                IsOn = !IsOn;
            }
        }

        private void StartTimer()
        {
            _timer.Interval = TimeSpan.FromSeconds(_duration);
            _timer.Start();
            IsOn = true;
            IsOnChanged(this, new DependencyPropertyChangedEventArgs(IsOnProperty, !IsOn, IsOn));
        }
        private bool IsValidStartTime()
        {
            if (DateTime.TryParseExact(StartTimeTextBox.Text, "HH:mm", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime parsedStartTime))
            {
                _startTime = DateTime.Today.Add(parsedStartTime.TimeOfDay);
                return true;
            }
            else
            {
                MessageBox.Show("Please enter a valid start time (HH:mm).");
                return false;
            }
        }

        private bool IsValidDuration()
        {
            if (int.TryParse(DurationTextBox.Text, out int result))
            {
                _duration = result;
                return true;
            }
            else
            {
                MessageBox.Show("Please enter a valid duration in seconds.");
                return false;
            }
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            _timer.Stop();
            IsOn = false;
        }

       

        private void ScheduleCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            SchedulePanel.Visibility = Visibility.Visible;
        }

        private void ScheduleCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            SchedulePanel.Visibility = Visibility.Collapsed;
        }
    }
    
}
